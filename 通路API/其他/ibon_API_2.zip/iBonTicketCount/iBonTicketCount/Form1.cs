﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;
using System.Net.Http;
using System.Threading.Tasks;
using System.Threading;
using Newtonsoft.Json;

namespace iBonTicketCount
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label4.Text = "";
            label7.Text = "";
            label8.Text = "";
            checkBox1.Checked = true;
        }

        //POST
        class WTicket
        {
            public string Products_Code { get; set; }
            public string Orders_STIME { get; set; }
            public string Orders_ETIME { get; set; }
        }

        class WTicketResp
        {
            public int TotalCount { get; set; }
            public int BlockCount { get; set; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateProductAsync();
            //string Products_Code=string.Empty;
            //if (checkBox1.Checked && !checkBox2.Checked)
            //{
            //    Products_Code += checkBox1.Text;
            //}
            //if (checkBox1.Checked && checkBox2.Checked)
            //{
            //    Products_Code += checkBox1.Text + "|" + checkBox2.Text;
            //}
            //if (!checkBox1.Checked && checkBox2.Checked)
            //{
            //    Products_Code += checkBox2.Text;
            //}
            //if (!checkBox1.Checked && !checkBox2.Checked)
            //{
            //    MessageBox.Show("請勾選商品代碼");
            //    return;
            //}
            //WTicket ticket = new WTicket
            //{

            //    Products_Code = Products_Code,
            //    Orders_STIME = textBox1.Text,
            //    Orders_ETIME = textBox2.Text,
            //};
            //var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:32278/WebService1.asmx/TxnRead");
            //httpWebRequest.ContentType = "application/json; charset=utf-8";
            //httpWebRequest.Method = "POST";

            //using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            //{
            //    streamWriter.Write(new JavaScriptSerializer().Serialize(ticket));
            //}
            //var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            //using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            //{
            //    var result = streamReader.ReadToEnd();
            //    var deserialized = JsonConvert.DeserializeObject<WTicketResp>(result);
            //    WTicketResp wTicketResp = deserialized;
            //    label7.Text = wTicketResp.TotalCount.ToString();
            //    label8.Text = wTicketResp.BlockCount.ToString();
            //}
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:32278/WebService1.asmx/ConnectTest");
            httpWebRequest.ContentType = "application/json; charset=utf-8";
            httpWebRequest.Method = "POST";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write("");
            }
            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                if (result=="true")
                    label4.Text = result;
                else
                    label4.Text = "false";
            }
        }

        private async void CreateProductAsync()
        {
            //string beginT = string.Format("{0:yyyy/MM/dd HH:00:00}", DateTime.Now);
            //string endT = string.Format("{0:yyyy/MM/dd HH:00:00}", DateTime.Now.AddHours(1));
            string Pro_code = (string)checkBox1.Text.ToString();
            string Pro_code2 = (string)checkBox2.Text.ToString();
            WTicket ticket = new WTicket
            {
                Products_Code = "B016H48L",
                Orders_STIME = textBox1.Text,
                Orders_ETIME = textBox2.Text,
            };

            HttpClient client = new HttpClient();
            HttpResponseMessage response = await client.PostAsync("http://localhost:32278/WebService1.asmx/TxnRead", new StringContent(
                                           new JavaScriptSerializer().Serialize(ticket), Encoding.UTF8, "application/json"));
            response.EnsureSuccessStatusCode();
            //string myConnStr = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            if (response.IsSuccessStatusCode)
            {
                // Get the response
                var customerJsonString = await response.Content.ReadAsStringAsync();
                // Deserialise the data (include the Newtonsoft JSON Nuget package if you don't already have it)
                var deserialized = JsonConvert.DeserializeObject<WTicketResp>(customerJsonString);
                // Do something with it
                WTicketResp wTicketResp = deserialized;
                label7.Text = wTicketResp.TotalCount.ToString();
                label8.Text = wTicketResp.BlockCount.ToString();
            }
        }
    }
}
