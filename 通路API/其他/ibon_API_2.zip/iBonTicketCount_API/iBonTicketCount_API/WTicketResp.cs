﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iBonTicketCount_API
{
    public class WTicketResp
    {
        public int TotalCount { get; set; }
        public int BlockCount { get; set; }
    }
}